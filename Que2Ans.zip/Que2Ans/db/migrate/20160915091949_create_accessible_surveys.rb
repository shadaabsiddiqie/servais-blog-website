class CreateAccessibleSurveys < ActiveRecord::Migration
  def change
    create_table :accessible_surveys do |t|

      t.timestamps null: false
    end
  end
end
