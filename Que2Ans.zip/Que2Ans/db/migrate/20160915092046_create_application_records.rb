class CreateApplicationRecords < ActiveRecord::Migration
  def change
    create_table :application_records do |t|

      t.timestamps null: false
    end
  end
end
