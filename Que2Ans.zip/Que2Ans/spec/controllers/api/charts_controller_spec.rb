require 'rails_helper'

RSpec.describe Api::ChartsController, type: :controller do

end
