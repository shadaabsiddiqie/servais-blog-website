require 'rails_helper'

RSpec.describe CollaborationsController, type: :controller do

end
