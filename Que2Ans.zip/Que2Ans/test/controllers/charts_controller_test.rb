require 'test_helper'

class ChartsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
