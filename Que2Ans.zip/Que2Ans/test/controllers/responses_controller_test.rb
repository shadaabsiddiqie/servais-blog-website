require 'test_helper'

class ResponsesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
