require 'test_helper'

class AccessibleSurveyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
