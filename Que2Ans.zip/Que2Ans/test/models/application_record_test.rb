require 'test_helper'

class ApplicationRecordTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
