require 'test_helper'

class CollaborationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
