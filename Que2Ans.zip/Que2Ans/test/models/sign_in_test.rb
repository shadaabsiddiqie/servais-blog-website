require 'test_helper'

class SignInTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
